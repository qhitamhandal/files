const util = require("util");
const chalk = require("chalk");
const fs = require("fs");
const axios = require("axios");
const fetch = require("node-fetch");
const ssh2 = require("ssh2");
const Obfus = require('js-confuser');
const { exec, spawn, execSync } = require('child_process');

const Premium = JSON.parse(fs.readFileSync("./Data/premium.json"))

module.exports = async (x, m) => {
try {
const isCmd = m?.body?.startsWith(m.prefix)
const quoted = m.quoted ? m.quoted : m
const mime = quoted?.msg?.mimetype || quoted?.mimetype || null
const args = m.body.trim().split(/ +/).slice(1)
const qmsg = (m.quoted || m)
const text = q = args.join(" ")
const isOwner = global.owner+"@s.whatsapp.net" == m.sender || m.key.fromMe
const command = isCmd ? m.body.slice(m.prefix.length).trim().split(' ').shift().toLowerCase() : ''
const isGrupReseller = Premium.includes(m.chat);
const botNumber = await x.decodeJid(x.user.id);
try {
  m.isGroup = m.chat.endsWith('g.us');
  m.metadata = m.isGroup ? await x.groupMetadata(m.chat).catch(() => ({})) : {};
  const participants = m.metadata.participants || [];
  m.isAdmin = participants.some(p => p.admin && p.id === m.sender);
  m.isBotAdmin = participants.some(p => p.admin && p.id === botNumber);
} catch {
  m.metadata = {};
  m.isAdmin = false;
  m.isBotAdmin = false;
}

//=============================================//

const FakeChannel = {
  key: {
    remoteJid: 'status@broadcast',
    fromMe: false,
    participant: '0@s.whatsapp.net'
  },
  message: {
    newsletterAdminInviteMessage: {
      newsletterJid: '123@newsletter',
      caption: `Skyzopedia.`,
      inviteExpiration: 0
    }
  }
}

const FakeLocation = {
  key: {
    participant: '0@s.whatsapp.net',
    ...(m.chat ? { remoteJid: 'status@broadcast' } : {})
  },
  message: {
    locationMessage: {
      name: `Skyzopedia.`,
      jpegThumbnail: ''
    }
  }
}

//=============================================//

switch (command) {
case "menu": {
const teks = `
  *Haii ${m.pushName} 👋*
 
  *➤ Storemenu*
  ▢ .jpm
  ▢ .jpmht
  ▢ .payment
  ▢ .proses
  ▢ .done
  
  *➤ Toolsmenu*
  ▢ .cekidch
  ▢ .subdomain
  ▢ .enchard
  ▢ .installpanel
  ▢ .startwings
  
  *➤ Panelmenu*
  ▢ .1gb
  ▢ .2gb
  ▢ .3gb
  ▢ .4gb
  ▢ .5gb
  ▢ .6gb
  ▢ .7gb
  ▢ .8gb
  ▢ .9gb
  ▢ .10gb
  ▢ .unlimited
  ▢ .listpanel
  ▢ .delpanel
  ▢ .cadmin
  ▢ .listadmin
  ▢ .deladmin
  ▢ .addakses
  ▢ .listakses
  ▢ .delakses
`
await x.sendMessage(m.chat, {text: teks, mentions: [m.sender]}, {quoted: FakeLocation })
}
break;

//=============================================//

case "enchard": case "encrypthard": {
if (!/javascript/g.test(mime)) return m.reply("dengan kirim file .js")
const strings = text ? text : "Skyzopedia"
let media = m.quoted ? await m.quoted.download() : await m.download()
let filename = m.quoted ? m.quoted.fakeObj.message.documentMessage.fileName : m.fakeObj.message.documentMessage.fileName
await m.reply("Proses Encrypt . . .")
await Obfus.obfuscate(media.toString(), {
  target: "node",
    preset: "high",
    compact: true,
    minify: true,
    flatten: true,

    identifierGenerator: function() {
        const originalString = `素晴座素晴${strings}`

        function hapusKarakterTidakDiinginkan(input) {
            return input.replace(
                /[^a-zA-Z/*ᨒZenn/*^/*($break)*/]/g, ''
            );
        }

        function stringAcak(panjang) {
            let hasil = '';
            const karakter = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
            const panjangKarakter = karakter.length;

            for (let i = 0; i < panjang; i++) {
                hasil += karakter.charAt(
                    Math.floor(Math.random() * panjangKarakter)
                );
            }
            return hasil;
        }

        return hapusKarakterTidakDiinginkan(originalString) + stringAcak(2);
    },

    renameVariables: true,
    renameGlobals: true,

    // Kurangi encoding dan pemisahan string untuk mengoptimalkan ukuran
    stringEncoding: 0.01, 
    stringSplitting: 0.1, 
    stringConcealing: true,
    stringCompression: true,
    duplicateLiteralsRemoval: true,

    shuffle: {
        hash: false,
        true: false
    },
    controlFlowFlattening: false, 
    opaquePredicates: false, 
    deadCode: false, 
    dispatcher: false,
    rgf: false,
    calculator: false,
    hexadecimalNumbers: false,
    movedDeclarations: true,
    objectExtraction: true,
    globalConcealing: true
}).then(async (obfuscated) => {
  await fs.writeFileSync(`./enchard-${filename}`, obfuscated.code)
  await x.sendMessage(m.chat, {document: await fs.readFileSync(`./enchard-${filename}`), mimetype: "application/javascript", fileName: filename, caption: `Sukses encrypt ${filename} ✅`}, {quoted: m})
}).catch(e => m.reply("Error :" + e))
await fs.unlinkSync(`./enchard-${filename}`)
}
break

//=============================================//

case "cekidch":
case "idch": {
  if (!text) return m.reply(`Contoh: *.${command}* linknya`); 
  if (!text.includes("https://whatsapp.com/channel/")) {
    return m.reply("Link tautan tidak valid");
  }
  let result = text.split("https://whatsapp.com/channel/")[1];
  let res = await x.newsletterMetadata("invite", result);
  let teks = `${res.id}`;
  return m.reply(teks);
}
break;

//=============================================//

case "addakses":
case "addaksesgc": {
    if (!isOwner) return m.reply("Fitur ini khusus untuk owner bot!");
    if (!m.isGroup) return m.reply("Fitur ini hanya bisa digunakan di dalam grup!");
    const groupId = m.chat;
    if (Premium.includes(groupId)) {
        return m.reply("Grup ini sudah memiliki akses reseller panel!");
    }
    Premium.push(groupId);
    try {
        await fs.writeFileSync("./Data/premium.json", JSON.stringify(Premium, null, 2));
        m.reply("Berhasil menambahkan grup sebagai reseller panel ✅");
    } catch (err) {
        console.error(err);
        m.reply("Gagal menyimpan data akses. Silakan coba lagi.");
    }
}
break;

//=============================================//

case "delakses":
case "delaksesgc": {
  if (!isOwner) return m.reply("Fitur ini khusus untuk owner bot!");
  if (!m.isGroup) return m.reply("Fitur ini hanya bisa digunakan di dalam grup!");
  if (Premium.length === 0) return m.reply("Tidak ada grup reseller panel.")
  const input = text ? text.trim() : m.chat
  if (input.toLowerCase() === "all") {
    Premium.length = 0
    fs.writeFileSync("./Data/premium.json", JSON.stringify(Premium, null, 2))
    return m.reply("Berhasil menghapus *semua grup reseller panel ✅")
  }
  if (!Premium.includes(input)) {
    return m.reply("Grup ini bukan grup reseller panel")
  }
  const index = Premium.indexOf(input)
  Premium.splice(index, 1)
  fs.writeFileSync("./Data/premium.json", JSON.stringify(Premium, null, 2))
  return m.reply("Berhasil menghapus grup reseller panel ✅")
}
break

//=============================================//

case "listakses": {
    if (!isOwner) return m.reply("Fitur ini khusus untuk owner bot!");
    if (Premium.length < 1) return m.reply("Tidak ada grup reseller panel.");
    const datagc = await x.groupFetchAllParticipating();
    let teks = "\n*List Grup Reseller Panel:*\n";

    for (let id of Premium) {
        const grup = datagc[id];
        const nama = grup ? grup.subject : "Grup tidak ditemukan atau bot bukan anggota";
        teks += `\n* ID: ${id}\n* Nama Grup: ${nama}\n`;
    }
    return m.reply(teks);
}
break;

//=============================================//

case "jpmht": {
if (!isOwner) return m.reply("Fitur ini untuk owner bot!")
if (!text) return m.reply(`Format salah!\n\nContoh penggunaan :\n.jpm teks & foto (opsional)`)
    let mediaPath
    const mimeType = mime
    if (/image/.test(mimeType)) {
        mediaPath = await x.downloadAndSaveMediaMessage(qmsg)
    }
    const allGroups = await x.groupFetchAllParticipating()
    const groupIds = Object.keys(allGroups)
    let successCount = 0
    const messageContent = mediaPath
        ? { image: await fs.readFileSync(mediaPath), caption: text, mentions: [] }
        : { text: text, mentions: [] }
    const senderChat = m.chat
    await m.reply(`Memproses ${mediaPath ? "JPM teks & foto" : "JPM teks"} hidetag ke ${groupIds.length} grup chat`)
    
    for (const groupId of groupIds) {
        try {
            messageContent.mentions = allGroups[groupId].participants.map(e => e.id)
            await x.sendMessage(groupId, messageContent, { quoted: FakeChannel })
            successCount++
        } catch (err) {
            console.error(`Gagal kirim ke grup ${groupId}:`, err)
        }
        await sleep(5000)
    }

    if (mediaPath) await fs.unlinkSync(mediaPath)
    await x.sendMessage(senderChat, {
        text: `JPM ${mediaPath ? "teks & foto" : "teks"} hidetag berhasil dikirim ke ${successCount} grup.`,
    }, { quoted: m })
}
break

//=============================================//

case "jpm": {
if (!isOwner) return m.reply("Fitur ini untuk owner bot!")
if (!text) return m.reply(`Format salah!\n\nContoh penggunaan :\n.jpm teks & foto (opsional)`)
    let mediaPath
    const mimeType = mime
    if (/image/.test(mimeType)) {
        mediaPath = await x.downloadAndSaveMediaMessage(qmsg)
    }
    const allGroups = await x.groupFetchAllParticipating()
    const groupIds = Object.keys(allGroups)
    let successCount = 0
    const messageContent = mediaPath
        ? { image: await fs.readFileSync(mediaPath), caption: text }
        : { text }
    const senderChat = m.chat
    await m.reply(`Memproses ${mediaPath ? "JPM teks & foto" : "JPM teks"} ke ${groupIds.length} grup chat`)
    
    for (const groupId of groupIds) {
        try {
            await x.sendMessage(groupId, messageContent, { quoted: FakeChannel })
            successCount++
        } catch (err) {
            console.error(`Gagal kirim ke grup ${groupId}:`, err)
        }
        await sleep(5000)
    }

    if (mediaPath) await fs.unlinkSync(mediaPath)
    await x.sendMessage(senderChat, {
        text: `JPM ${mediaPath ? "teks & foto" : "teks"} berhasil dikirim ke ${successCount} grup.`,
    }, { quoted: m })
}
break

//=============================================//

case "sendtesti":
case "testi":
case "uptesti": {
    if (!isOwner) return m.reply("Fitur ini untuk owner bot!")
    if (!text) return m.reply(`Format salah!\n\nContoh penggunaan :\n.${command} teks & foto (opsional)`)
    let mediaPath
    const mimeType = mime
    if (/image/.test(mimeType)) {
        mediaPath = await x.downloadAndSaveMediaMessage(qmsg)
    }
    const allGroups = await x.groupFetchAllParticipating()
    const groupIds = Object.keys(allGroups)
    let successCount = 0
    const messageText = text
    const senderChat = m.chat
    await m.reply(`Memproses jpm testimoni ke saluran & ${groupIds.length} grup...`)
    try {
        const messageContent = mediaPath
            ? { image: await fs.readFileSync(mediaPath), caption: messageText }
            : { text: messageText }

        await x.sendMessage(global.idChannel, messageContent)
    } catch (err) {
        console.error("Gagal mengirim ke saluran:", err)
    }
    const groupMessage = mediaPath
        ? { image: await fs.readFileSync(mediaPath), caption: messageText }
        : { text: messageText }
    for (const groupId of groupIds) {
        try {
            await x.sendMessage(groupId, {
                ...groupMessage,
                contextInfo: {
                    isForwarded: true,
                    mentionedJid: [m.sender],
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: global.idChannel,
                        newsletterName: global.namaChannel
                    }
                }
            }, { quoted: FakeLocation })

            successCount++
        } catch (err) {
            console.error(`Gagal mengirim ke grup ${groupId}:`, err)
        }
        await sleep(5000)
    }
    if (mediaPath) {
        await fs.unlinkSync(mediaPath)
    }
    await x.sendMessage(senderChat, {
        text: `Testimoni berhasil dikirim ke saluran & ${successCount} grup.`,
    }, { quoted: m })

}
break

//=============================================//

case "done":
case "don":
case "proses":
case "ps": {
    if (!isOwner) return;
    if (!text) return m.reply(`*Contoh penggunaan:*\n.${command} <teks transaksi>`);
    const status = /done|don/.test(command) ? "Transaksi Done ✅" : "Dana Masuk ✅";
    const teks = `
*${status}*

📦 \`${text}\`
🗓️ ${global.tanggal(Date.now())}

* *Testimoni*
whatsapp.com/channel/0029Vb8cgMEH5JLqiOEdbH1t
* *Marketplace*
chat.whatsapp.com/LEgsVRF1OOLJaS3ESkuX0l
`;
    await x.sendMessage(m.chat, {
        text: teks,
        contextInfo: {
            isForwarded: true,
            forwardingScore: 9999
        }
    }, { quoted: FakeLocation });
}
break;

//=============================================//

case "installpanel": {
    if (!isOwner) return m.reply("Fitur ini untuk owner bot!")
    if (!text) return m.reply("Contoh: *.instalpanel* ipvps|pwvps|panel.com|node.com|ramserver *(contoh 100000)*");
    
    let vii = text.split("|");
    if (vii.length < 5) return m.reply("Contoh: *.instalpanel* ipvps|pwvps|panel.com|node.com|ramserver *(contoh 100000)*");
    
    const ress = new ssh2.Client();
    const connSettings = {
        host: vii[0],
        port: '22',
        username: 'root',
        password: vii[1]
    };
    
    const jids = m.chat
    const pass = "admin001";
    let passwordPanel = pass;
    const domainpanel = vii[2];
    const domainnode = vii[3];
    const ramserver = vii[4];
    const deletemysql = `\n`;
    const commandPanel = `bash <(curl -s https://pterodactyl-installer.se)`;
    
    async function instalWings() {
    ress.exec(commandPanel, async (err, stream) => {
        if (err) {
            console.error('Wings installation error:', err);
            m.reply(`Gagal memulai instalasi Wings: ${err.message}`);
            return ress.end();
        }
        
        stream.on('close', async (code, signal) => {
            await InstallNodes()            
        }).on('data', async (data) => {
            const dataStr = data.toString();
            console.log('Wings Install: ' + dataStr);
            
            if (dataStr.includes('Input 0-6')) {
                stream.write('1\n');
            }
            else if (dataStr.includes('(y/N)')) {
                stream.write('y\n');
            }
            else if (dataStr.includes('Enter the panel address (blank for any address)')) {
                stream.write(`${domainpanel}\n`);
            }
            else if (dataStr.includes('Database host username (pterodactyluser)')) {
                stream.write('admin\n');
            }
            else if (dataStr.includes('Database host password')) {
                stream.write('admin\n');
            }
            else if (dataStr.includes('Set the FQDN to use for Let\'s Encrypt (node.example.com)')) {
                stream.write(`${domainnode}\n`);
            }
            else if (dataStr.includes('Enter email address for Let\'s Encrypt')) {
                stream.write('admin@gmail.com\n');
            }
        }).stderr.on('data', async (data) => {
            console.error('Wings Install Error: ' + data);
            m.reply(`Error pada instalasi Wings:\n${data}`);
        });
    });
}

    async function InstallNodes() {
        ress.exec('bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/createnode.sh)', async (err, stream) => {
            if (err) throw err;
            
            stream.on('close', async (code, signal) => {
                let teks = `
*Install Panel Telah Berhasil ✅*

*Berikut Detail Akun Panel Kamu 📦*

*👤 Username :* admin
*🔐 Password :* ${passwordPanel}
*🌐 ${domainpanel}*

Silahkan setting alocation & ambil token node di node yang sudah di buat oleh bot

*Cara menjalankan wings :*
*.startwings* ipvps|pwvps|tokennode
`;
                await x.sendMessage(jids, {text: teks}, {quoted: m})
                ress.end();
            }).on('data', async (data) => {
                await console.log(data.toString());
                if (data.toString().includes("Masukkan nama lokasi: ")) {
                    stream.write('Singapore\n');
                }
                if (data.toString().includes("Masukkan deskripsi lokasi: ")) {
                    stream.write('Node By Skyzo\n');
                }
                if (data.toString().includes("Masukkan domain: ")) {
                    stream.write(`${domainnode}\n`);
                }
                if (data.toString().includes("Masukkan nama node: ")) {
                    stream.write('Skyzopedia\n');
                }
                if (data.toString().includes("Masukkan RAM (dalam MB): ")) {
                    stream.write(`${ramserver}\n`);
                }
                if (data.toString().includes("Masukkan jumlah maksimum disk space (dalam MB): ")) {
                    stream.write(`${ramserver}\n`);
                }
                if (data.toString().includes("Masukkan Locid: ")) {
                    stream.write('1\n');
                }
            }).stderr.on('data', async (data) => {
                console.log('Stderr : ' + data);
                m.reply(`Error pada instalasi Wings: ${data}`);
            });
        });
    }

    async function instalPanel() {
        ress.exec(commandPanel, (err, stream) => {
            if (err) throw err;
            
            stream.on('close', async (code, signal) => {
                await instalWings();
            }).on('data', async (data) => {
                if (data.toString().includes('Input 0-6')) {
                    stream.write('0\n');
                } 
                if (data.toString().includes('(y/N)')) {
                    stream.write('y\n');
                } 
                if (data.toString().includes('Database name (panel)')) {
                    stream.write('\n');
                }
                if (data.toString().includes('Database username (pterodactyl)')) {
                    stream.write('admin\n');
                }
                if (data.toString().includes('Password (press enter to use randomly generated password)')) {
                    stream.write('admin\n');
                } 
                if (data.toString().includes('Select timezone [Europe/Stockholm]')) {
                    stream.write('Asia/Jakarta\n');
                } 
                if (data.toString().includes('Provide the email address that will be used to configure Let\'s Encrypt and Pterodactyl')) {
                    stream.write('admin@gmail.com\n');
                } 
                if (data.toString().includes('Email address for the initial admin account')) {
                    stream.write('admin@gmail.com\n');
                } 
                if (data.toString().includes('Username for the initial admin account')) {
                    stream.write('admin\n');
                } 
                if (data.toString().includes('First name for the initial admin account')) {
                    stream.write('admin\n');
                } 
                if (data.toString().includes('Last name for the initial admin account')) {
                    stream.write('admin\n');
                } 
                if (data.toString().includes('Password for the initial admin account')) {
                    stream.write(`${passwordPanel}\n`);
                } 
                if (data.toString().includes('Set the FQDN of this panel (panel.example.com)')) {
                    stream.write(`${domainpanel}\n`);
                } 
                if (data.toString().includes('Do you want to automatically configure UFW (firewall)')) {
                    stream.write('y\n')
                } 
                if (data.toString().includes('Do you want to automatically configure HTTPS using Let\'s Encrypt? (y/N)')) {
                    stream.write('y\n');
                } 
                if (data.toString().includes('Select the appropriate number [1-2] then [enter] (press \'c\' to cancel)')) {
                    stream.write('1\n');
                } 
                if (data.toString().includes('I agree that this HTTPS request is performed (y/N)')) {
                    stream.write('y\n');
                }
                if (data.toString().includes('Proceed anyways (your install will be broken if you do not know what you are doing)? (y/N)')) {
                    stream.write('y\n');
                } 
                if (data.toString().includes('(yes/no)')) {
                    stream.write('y\n');
                } 
                if (data.toString().includes('Initial configuration completed. Continue with installation? (y/N)')) {
                    stream.write('y\n');
                } 
                if (data.toString().includes('Still assume SSL? (y/N)')) {
                    stream.write('y\n');
                } 
                if (data.toString().includes('Please read the Terms of Service')) {
                    stream.write('y\n');
                }
                if (data.toString().includes('(A)gree/(C)ancel:')) {
                    stream.write('A\n');
                } 
                console.log('Logger: ' + data.toString());
            }).stderr.on('data', (data) => {
                m.reply(`Error Terjadi kesalahan :\n${data}`);
                console.log('STDERR: ' + data);
            });
        });
    }

    ress.on('ready', async () => {
        await m.reply(`*Memproses install server panel 🚀*\n\n` +
                     `*IP Address:* ${vii[0]}\n` +
                     `*Domain Panel:* ${domainpanel}\n\n` +
                     `Mohon tunggu 10-20 menit hingga proses install selesai`);
        
        ress.exec(deletemysql, async (err, stream) => {
            if (err) throw err;
            
            stream.on('close', async (code, signal) => {
                await instalPanel();
            }).on('data', async (data) => {
                await stream.write('\t');
                await stream.write('\n');
                await console.log(data.toString());
            }).stderr.on('data', async (data) => {
                m.reply(`Error Terjadi kesalahan :\n${data}`);
                console.log('Stderr : ' + data);
            });
        });
    });

    ress.on('error', (err) => {
        console.error('SSH Connection Error:', err);
        m.reply(`Gagal terhubung ke server: ${err.message}`);
    });

    ress.connect(connSettings);
}
break

case "startwings":
case "configurewings": {
    if (!isOwner) return m.reply("Fitur ini untuk owner bot!")
    let t = text.split('|');
    if (t.length < 3) return m.reply("Contoh: *.startwings* ipvps|pwvps|token_node");

    let ipvps = t[0].trim();
    let passwd = t[1].trim();
    let token = t[2].trim();

    const connSettings = {
        host: ipvps,
        port: 22,
        username: 'root',
        password: passwd
    };

    const command = `${token} && systemctl start wings`;

    const ress = new ssh2.Client();

    ress.on('ready', () => {
        ress.exec(command, (err, stream) => {
            if (err) {
                m.reply('Gagal menjalankan perintah di VPS');
                ress.end();
                return;
            }

            stream.on('close', async (code, signal) => {
                await m.reply("*Berhasil menjalankan wings ✅*");
                ress.end();
            }).on('data', (data) => {
                console.log("STDOUT:", data.toString());
            }).stderr.on('data', (data) => {
                console.log("STDERR:", data.toString());
                // Opsi jika perlu input interaktif
                stream.write("y\n");
                stream.write("systemctl start wings\n");
                m.reply('Terjadi error saat eksekusi:\n' + data.toString());
            });
        });
    }).on('error', (err) => {
        console.log('Connection Error:', err.message);
        m.reply('Gagal terhubung ke VPS: IP atau password salah.');
    }).connect(connSettings);
}
break;

case "1gb": case "2gb": case "3gb": case "4gb": case "5gb": 
case "6gb": case "7gb": case "8gb": case "9gb": case "10gb": 
case "unlimited": case "unli": {
    if (!isOwner && !isGrupReseller) {
        return m.reply(`Fitur ini untuk developer bot`);
    }
    if (!text) return m.reply(`*Contoh penggunaan :*\n.${command} username,6285XXX`)

    let nomor, usernem;
    let tek = text.split(",");
    if (tek.length > 1) {
        let [users, nom] = tek.map(t => t.trim());
        if (!users || !nom) return m.reply(`Contoh penggunaan :\n.${command} username,6285XXX`)
        nomor = nom.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
        usernem = users.toLowerCase();
    } else {
        usernem = text.toLowerCase();
        nomor = m.isGroup ? m.sender : m.chat
    }

    try {
        var onWa = await x.onWhatsApp(nomor.split("@")[0]);
        if (onWa.length < 1) return m.reply("Nomor target tidak terdaftar di WhatsApp!");
    } catch (err) {
        return m.reply("Terjadi kesalahan saat mengecek nomor WhatsApp: " + err.message);
    }

    // Mapping RAM, Disk, dan CPU
    const resourceMap = {
        "1gb": { ram: "1000", disk: "1000", cpu: "40" },
        "2gb": { ram: "2000", disk: "1000", cpu: "60" },
        "3gb": { ram: "3000", disk: "2000", cpu: "80" },
        "4gb": { ram: "4000", disk: "2000", cpu: "100" },
        "5gb": { ram: "5000", disk: "3000", cpu: "120" },
        "6gb": { ram: "6000", disk: "3000", cpu: "140" },
        "7gb": { ram: "7000", disk: "4000", cpu: "160" },
        "8gb": { ram: "8000", disk: "4000", cpu: "180" },
        "9gb": { ram: "9000", disk: "5000", cpu: "200" },
        "10gb": { ram: "10000", disk: "5000", cpu: "220" },
        "unlimited": { ram: "0", disk: "0", cpu: "0" }
    };
    
    let { ram, disk, cpu } = resourceMap[command] || { ram: "0", disk: "0", cpu: "0" };

    let username = usernem.toLowerCase();
    let email = username + "@gmail.com";
    let name = global.capital(username) + " Server";
    let password = username + "001";

    try {
        let f = await fetch(domain + "/api/application/users", {
            method: "POST",
            headers: { "Accept": "application/json", "Content-Type": "application/json", "Authorization": "Bearer " + apikey },
            body: JSON.stringify({ email, username, first_name: name, last_name: "Server", language: "en", password })
        });
        let data = await f.json();
        if (data.errors) return m.reply("Error: " + JSON.stringify(data.errors[0], null, 2));
        let user = data.attributes;

        let f1 = await fetch(domain + `/api/application/nests/${nestid}/eggs/` + egg, {
            method: "GET",
            headers: { "Accept": "application/json", "Content-Type": "application/json", "Authorization": "Bearer " + apikey }
        });
        let data2 = await f1.json();
        let startup_cmd = data2.attributes.startup;

        let f2 = await fetch(domain + "/api/application/servers", {
            method: "POST",
            headers: { "Accept": "application/json", "Content-Type": "application/json", "Authorization": "Bearer " + apikey },
            body: JSON.stringify({
                name,
                description: global.tanggal(Date.now()),
                user: user.id,
                egg: parseInt(egg),
                docker_image: "ghcr.io/parkervcp/yolks:nodejs_20",
                startup: startup_cmd,
                environment: { INST: "npm", USER_UPLOAD: "0", AUTO_UPDATE: "0", CMD_RUN: "npm start" },
                limits: { memory: ram, swap: 0, disk, io: 500, cpu },
                feature_limits: { databases: 5, backups: 5, allocations: 5 },
                deploy: { locations: [parseInt(loc)], dedicated_ip: false, port_range: [] },
            })
        });
        let result = await f2.json();
        if (result.errors) return m.reply("Error: " + JSON.stringify(result.errors[0], null, 2));
        
        let server = result.attributes;
        var orang = nomor
        if (orang !== m.chat) {
        await m.reply(`Berhasil membuat akun panel ✅\ndata akun sudah di kirim ke ${nomor.split("@")[0]}`)
        }

let teks = `
*Berikut detail akun panel kamu*

📡 Server ID: ${server.id}
👤 Username: \`${user.username}\`
🔐 Password: \`${password}\`
🗓️ Tanggal Aktivasi: ${global.tanggal(Date.now())}

*⚙️ Spesifikasi server panel*
- RAM: ${ram == "0" ? "Unlimited" : ram / 1000 + "GB"}
- Disk: ${disk == "0" ? "Unlimited" : disk / 1000 + "GB"}
- CPU: ${cpu == "0" ? "Unlimited" : cpu + "%"}
- Panel: ${global.domain}

*Rules pembelian panel :*  
- Masa aktif 30 hari  
- Data bersifat pribadi, mohon disimpan dengan aman  
- Garansi berlaku 15 hari (1x replace)  
- Klaim garansi wajib menyertakan *bukti chat pembelian*
`
        await x.sendMessage(orang, { text: teks }, { quoted: m });
    } catch (err) {
        return m.reply("Terjadi kesalahan: " + err.message);
    }
}
break

//=============================================//

case "listpanel":
case "listp":
case "listserver": {
    if (!isOwner && !isGrupReseller) {
        return m.reply(`Fitur ini untuk developer bot`);
    }

    try {
        const response = await fetch(`${domain}/api/application/servers`, {
            method: "GET",
            headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: `Bearer ${apikey}`,
            },
        });

        const result = await response.json();
        const servers = result.data;

        if (!servers || servers.length === 0) {
            return m.reply("Tidak ada server panel!");
        }

        let messageText = `\n*Total server panel :* ${servers.length}\n`

        for (const server of servers) {
            const s = server.attributes;

            const resStatus = await fetch(`${domain}/api/client/servers/${s.uuid.split("-")[0]}/resources`, {
                method: "GET",
                headers: {
                    Accept: "application/json",
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${capikey}`,
                },
            });

            const statusData = await resStatus.json();

            const ram = s.limits.memory === 0
                ? "Unlimited"
                : s.limits.memory >= 1024
                ? `${Math.floor(s.limits.memory / 1024)} GB`
                : `${s.limits.memory} MB`;

            const disk = s.limits.disk === 0
                ? "Unlimited"
                : s.limits.disk >= 1024
                ? `${Math.floor(s.limits.disk / 1024)} GB`
                : `${s.limits.disk} MB`;

            const cpu = s.limits.cpu === 0
                ? "Unlimited"
                : `${s.limits.cpu}%`;

            messageText += `
*📡 ID ${s.id} [ ${s.name} ]*
- RAM : *${ram}*
- Disk : *${disk}*
- CPU : *${cpu}*
- Created : *${s.created_at.split("T")[0]}*\n`;
        }                  
        await x.sendMessage(m.chat, { text: messageText }, { quoted: m });

    } catch (err) {
        console.error("Error listing panel servers:", err);
        m.reply("Terjadi kesalahan saat mengambil data server.");
    }
}
break;

//=============================================//

case "delpanel": {
    if (!isOwner) return m.reply(`Fitur ini hanya untuk developer bot`);
    if (!text) return m.reply(`*Contoh penggunaan:*\n.${command} id`);
    
    try {
        const serverResponse = await fetch(domain + "/api/application/servers", {
            method: "GET",
            headers: {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": "Bearer " + apikey
            }
        });
        const serverData = await serverResponse.json();
        const servers = serverData.data;
        
        let serverName;
        let serverSection;
        let serverFound = false;
        
        for (const server of servers) {
            const serverAttr = server.attributes;
            
            if (Number(text) === serverAttr.id) {
                serverSection = serverAttr.name.toLowerCase();
                serverName = serverAttr.name;
                serverFound = true;
                
                const deleteServerResponse = await fetch(domain + `/api/application/servers/${serverAttr.id}`, {
                    method: "DELETE",
                    headers: {
                        "Accept": "application/json",
                        "Content-Type": "application/json",
                        "Authorization": "Bearer " + apikey
                    }
                });
                
                if (!deleteServerResponse.ok) {
                    const errorData = await deleteServerResponse.json();
                    console.error("Gagal menghapus server:", errorData);
                }
                
                break;
            }
        }
        
        if (!serverFound) {
            return m.reply("Gagal menghapus server!\nID server tidak ditemukan");
        }
        
        const userResponse = await fetch(domain + "/api/application/users", {
            method: "GET",
            headers: {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": "Bearer " + apikey
            }
        });
        const userData = await userResponse.json();
        const users = userData.data;
        
        for (const user of users) {
            const userAttr = user.attributes;
            
            if (userAttr.first_name.toLowerCase() === serverSection) {
                const deleteUserResponse = await fetch(domain + `/api/application/users/${userAttr.id}`, {
                    method: "DELETE",
                    headers: {
                        "Accept": "application/json",
                        "Content-Type": "application/json",
                        "Authorization": "Bearer " + apikey
                    }
                });
                
                if (!deleteUserResponse.ok) {
                    const errorData = await deleteUserResponse.json();
                    console.error("Gagal menghapus user:", errorData);
                }
                
                break;
            }
        }
        
        await m.reply(`Sukses menghapus server panel *${capital(serverName)}*`);
        
    } catch (error) {
        console.error("Error dalam proses delpanel:", error);
        await m.reply("Terjadi kesalahan saat memproses permintaan");
    }
}
break;

//=============================================//

case "cadmin": {
    if (!isOwner) return m.reply(`Fitur ini untuk developer bot`);
    if (!text) return m.reply(`*Contoh penggunaan :*\n.${command} username,6285XXX`);
    let nomor, usernem;
    const tek = text.split(",");
    if (tek.length > 1) {
        let [users, nom] = tek;
        if (!users || !nom) return m.reply(`*Contoh penggunaan :*\n.${command} username,6285XXX`);

        nomor = nom.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
        usernem = users.toLowerCase();
    } else {
        usernem = text.toLowerCase();
        nomor = m.isGroup ? m.sender : m.chat;
    }

    const onWa = await x.onWhatsApp(nomor.split("@")[0]);
    if (onWa.length < 1) return m.reply("Nomor target tidak terdaftar di WhatsApp!");

    const username = usernem.toLowerCase();
    const email = `${username}@gmail.com`;
    const name = global.capital(args[0]);
    const password = `${username}001`;

    try {
        const res = await fetch(`${domain}/api/application/users`, {
            method: "POST",
            headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: `Bearer ${apikey}`
            },
            body: JSON.stringify({
                email,
                username,
                first_name: name,
                last_name: "Admin",
                root_admin: true,
                language: "en",
                password
            })
        });

        const data = await res.json();
        if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));

        const user = data.attributes;
        const orang = nomor;

        if (nomor !== m.chat) {
            await m.reply(`Berhasil membuat akun admin panel ✅\nData akun sudah dikirim ke ${nomor.split("@")[0]}`);
        }

        const teks = `
*Berikut detail akun admin panel*

📡 Server ID: ${user.id}
👤 Username: \`${user.username}\`
🔐 Password: \`${password}\`
🗓️ Tanggal Aktivasi: ${global.tanggal(Date.now())}
*🌐* ${global.domain}

*Rules pembelian admin panel:*  
- Masa aktif 30 hari  
- Data bersifat pribadi, mohon disimpan dengan aman  
- Garansi berlaku 15 hari (1x replace)  
- Klaim garansi wajib menyertakan *bukti chat pembelian*
        `;

        await x.sendMessage(orang, { text: teks }, { quoted: m });

    } catch (err) {
        console.error(err);
        m.reply("Terjadi kesalahan saat membuat akun admin panel.");
    }
}
break;

//=============================================//

case "deladmin": {
    if (!isOwner) return m.reply(`Fitur ini hanya untuk developer bot`);
    if (!text) return m.reply(`*Contoh penggunaan:*\n.${command} id`);
    try {
        const res = await fetch(`${domain}/api/application/users`, {
            method: "GET",
            headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: `Bearer ${apikey}`
            }
        });

        const data = await res.json();
        const users = data.data;

        let targetAdmin = users.find(
            (e) => e.attributes.id == args[0] && e.attributes.root_admin === true
        );

        if (!targetAdmin) {
            return m.reply("Gagal menghapus akun!\nID user tidak ditemukan");
        }

        const idadmin = targetAdmin.attributes.id;
        const username = targetAdmin.attributes.username;

        const delRes = await fetch(`${domain}/api/application/users/${idadmin}`, {
            method: "DELETE",
            headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: `Bearer ${apikey}`
            }
        });

        if (!delRes.ok) {
            const errData = await delRes.json();
            return m.reply(`Gagal menghapus akun admin!\n${JSON.stringify(errData.errors[0], null, 2)}`);
        }

        await m.reply(`Sukses menghapus akun admin panel *${global.capital(username)}*`);

    } catch (err) {
        console.error(err);
        m.reply("Terjadi kesalahan saat menghapus akun admin.");
    }
}
break;

//=============================================//

case "listadmin": {
    if (!isOwner) return m.reply(`Fitur ini hanya untuk developer bot`);

    try {
        const res = await fetch(`${domain}/api/application/users`, {
            method: "GET",
            headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: `Bearer ${apikey}`
            }
        });

        const data = await res.json();
        const users = data.data;

        const adminUsers = users.filter(u => u.attributes.root_admin === true);
        if (adminUsers.length < 1) return m.reply("Tidak ada admin panel.");

        let teks = `\n*Total admin panel :* ${adminUsers.length}\n`
        adminUsers.forEach((admin, idx) => {
            teks += `
📡 *${admin.attributes.id} [ ${admin.attributes.first_name} ]*
* Nama : *${admin.attributes.first_name}*
* Created : ${admin.attributes.created_at.split("T")[0]}
`;
        });

        await x.sendMessage(m.chat, { text: teks }, { quoted: m });

    } catch (err) {
        console.error(err);
        m.reply("Terjadi kesalahan saat mengambil data admin.");
    }
}
break;

//=============================================//

case "payment": case "pay": {
const teksPayment = `
*Daftar Payment Skyzopedia 🔖*

* *Dana :* 085624297893
* *Ovo :* -
* *Gopay :* -

*Penting!*
Wajib kirimkan bukti transfer demi keamanan bersama!
`
return x.sendMessage(m.chat, {image: {url: "https://files.catbox.moe/uadqj0.jpg"}, caption: teksPayment}, {quoted: m})
}
break;

//=============================================//

case "subdo": case "subdomain": case "domain": { 
if (!isOwner) return m.reply(`Fitur ini hanya untuk developer bot`);
if (!text) {
    const obj = Object.keys(subdomain);
    let teks = `\n`;
    obj.forEach((domain, index) => {
        teks += `* ${index + 1}. ${domain}\n`;
    });
    teks += `\nContoh Penggunaan :\n *.domain* 2 host|ipvps\n`;
    return m.reply(teks);
}

if (!args[0] || isNaN(args[0])) return m.reply("Domain tidak ditemukan!");

const dom = Object.keys(subdomain);
const domainIndex = Number(args[0]) - 1;
if (domainIndex >= dom.length || domainIndex < 0) return m.reply("Domain tidak ditemukan!");

if (!args[1] || !args[1].includes("|")) return m.reply("Hostname/IP Tidak ditemukan!");

let tldnya = dom[domainIndex];
const [host, ip] = args[1].split("|").map(str => str.trim());

async function subDomain1(host, ip) {
    return new Promise((resolve) => {
        axios.post(
            `https://api.cloudflare.com/client/v4/zones/${subdomain[tldnya].zone}/dns_records`,
            {
                type: "A",
                name: `${host.replace(/[^a-z0-9.-]/gi, "")}.${tldnya}`,
                content: ip.replace(/[^0-9.]/gi, ""),
                ttl: 3600,
                priority: 10,
                proxied: false,
            },
            {
                headers: {
                    Authorization: `Bearer ${subdomain[tldnya].apitoken}`,
                    "Content-Type": "application/json",
                },
            }
        ).then(response => {
            let res = response.data;
            if (res.success) {
                resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
            } else {
                resolve({ success: false, error: "Gagal membuat subdomain." });
            }
        }).catch(error => {
            let errorMsg = error.response?.data?.errors?.[0]?.message || error.message || "Terjadi kesalahan!";
            resolve({ success: false, error: errorMsg });
        });
    });
}

let teks = `*Berhasil membuat subdomain ✅*\n\n*🚀 IP Address :* ${ip}\n`;
const domnode = `node${getRandom("")}.${host}`;

for (let i = 0; i < 2; i++) {
    let subHost = i === 0 ? host.toLowerCase() : domnode;
    try {
        let result = await subDomain1(subHost, ip);
        if (result.success) {
            teks += `*🌐 ${result.name}*\n`;
        } else {
            return m.reply(result.error);
        }
    } catch (err) {
        return m.reply("Error: " + err.message);
    }
}

await m.reply(teks);

}
break;

//=============================================//

case "backupsc":
case "bck":
case "backup": {
    if (m.sender.split("@")[0] !== global.owner && m.sender !== botNumber)
        return m.reply("Fitur ini hanya untuk owner pemilik bot!");
    try {        
        const tmpDir = "./Tmp";
        if (fs.existsSync(tmpDir)) {
            const files = fs.readdirSync(tmpDir).filter(f => !f.endsWith(".js"));
            for (let file of files) {
                fs.unlinkSync(`${tmpDir}/${file}`);
            }
        }
        await m.reply("Processing Backup Script . .");        
        const name = `Script-Skyzopedia`; 
        const exclude = ["node_modules", "Auth", "package-lock.json", "yarn.lock", ".npm", ".cache"];
        const filesToZip = fs.readdirSync(".").filter(f => !exclude.includes(f) && f !== "");

        if (!filesToZip.length) return m.reply("Tidak ada file yang dapat di-backup.");

        execSync(`zip -r ${name}.zip ${filesToZip.join(" ")}`);

        await x.sendMessage(m.sender, {
            document: fs.readFileSync(`./${name}.zip`),
            fileName: `${name}.zip`,
            mimetype: "application/zip"
        }, { quoted: m });

        fs.unlinkSync(`./${name}.zip`);

        if (m.chat !== m.sender) m.reply("Script bot berhasil dikirim ke private chat.");
    } catch (err) {
        console.error("Backup Error:", err);
        m.reply("Terjadi kesalahan saat melakukan backup.");
    }
}
break;

//=============================================//

case "self":
case "public": {
  if (!isOwner) return m.reply("❌ Akses ditolak! Perintah ini hanya untuk developer.");
  const mode = command === "public";
  x.public = mode;
  return m.reply(`✅ Bot berhasil beralih ke mode *${mode ? "public" : "self"}*.`);
}


//=============================================//

default:
if (m.text.startsWith("=>")) {
    if (!isOwner) return;

    try {
        const result = await eval(`(async () => { ${text} })()`);
        const output = typeof result !== "string" ? util.inspect(result) : result;
        return x.sendMessage(m.chat, { text: util.format(output) }, { quoted: m });
    } catch (err) {
        return x.sendMessage(m.chat, { text: util.format(err) }, { quoted: m });
    }
}

if (m.text.startsWith(">")) {
    if (!isOwner) return;

    try {
        let result = await eval(text);
        if (typeof result !== "string") result = util.inspect(result);
        return x.sendMessage(m.chat, { text: util.format(result) }, { quoted: m });
    } catch (err) {
        return x.sendMessage(m.chat, { text: util.format(err) }, { quoted: m });
    }
}

if (m.text.startsWith('$')) {
    if (!isOwner) return;
    
    exec(m.text.slice(2), (err, stdout) => {
        if (err) {
            return x.sendMessage(m.chat, { text: err.toString() }, { quoted: m });
        }
        if (stdout) {
            return x.sendMessage(m.chat, { text: util.format(stdout) }, { quoted: m });
        }
    });
}

}

} catch (err) {
console.log(err)
await x.sendMessage(global.owner+"@s.whatsapp.net", {text: err.toString()}, {quoted: m})
}}

//=============================================//

process.on("uncaughtException", (err) => {
console.error("Caught exception:", err);
});

let file = require.resolve(__filename);
fs.watchFile(file, () => {
    fs.unwatchFile(file);
    console.log(chalk.blue(">> Update File:"), chalk.black.bgWhite(__filename));
    delete require.cache[file];
    require(file);
});